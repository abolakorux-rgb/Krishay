# Security Notes — Final

Doginex از PDO prepared statements، CSRF، password hashing، session regeneration، role-based authorization، upload MIME validation، randomized filenames، protected storage، download tokens، expiration، rate limiting برای ورود مدیریت و audit log استفاده می‌کند.

فایل‌های دیجیتال در `storage/downloads` نگهداری می‌شوند و از web مستقیم سرو نمی‌شوند. لینک دانلود پس از پرداخت معتبر با توکن 64-character hex ساخته می‌شود و سقف 10 دانلود/30 روز دارد.

فایل‌های دیجیتال قدیمی که در سفارش پرداخت‌شده snapshot شده‌اند هنگام جایگزینی یا حذف محصول به‌طور خودکار حذف نمی‌شوند تا تاریخچه سفارش‌ها خراب نشود.

برای production باید HTTPS، PHP و MySQL/MariaDB به‌روز، دسترسی مناسب فایل‌ها، backup منظم و malware scanning سمت هاست برقرار باشد. همچنین یک تست واقعی پرداخت و یک تست خارجی امنیتی قبل از launch نهایی توصیه می‌شود.

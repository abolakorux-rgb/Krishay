# Deployment Guide

### cPanel / DirectAdmin
Upload all files into the domain document root. Keep the directory structure intact. PHP 8.2+ and PDO MySQL are required. The site uses `.htaccess` rewrite rules for clean URLs.

### Installer
Browse to `https://YOUR-DOMAIN/install.php`. The installer creates the database schema, initial admin and default settings and then writes `config.php`. A lock file is created under `storage/installed.lock` so repeated installs are blocked.

### Permissions
The web process needs write access to `uploads/products` and `storage/downloads` during product upload. Do not grant execute permissions to uploaded files. Keep `storage` denied from direct web access.

### SSL
Use HTTPS in production. Payment callbacks and session cookies should run on HTTPS.

# Admin Guide

Open `/admin/login` and sign in with the administrator created by the installer.

- Products: create/edit title, slug, category, price, compare-at price, SKU, brand, publish status, SEO metadata, external link, multiple images and protected digital file.
- Categories: add, edit, reorder, activate/deactivate, and delete.
- Coupons: percentage or fixed discount, minimum order, usage limit, start/end time.
- Orders: inspect orders, totals, payment and lifecycle status.
- Media: inspect uploaded media records.
- Settings: site name, URL, SEO description, contact, footer, hero copy, ZarinPal settings and administrator credentials.
- Logs: security-relevant administrator activity.

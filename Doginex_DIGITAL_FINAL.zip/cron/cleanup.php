<?php
if(PHP_SAPI!=='cli'){http_response_code(403);exit('CLI only');}
require __DIR__.'/../includes/bootstrap.php';
release_expired_reservations();
echo "Doginex cleanup completed.\n";

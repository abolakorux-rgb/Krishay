# Changelog

## 1.0.0
- Initial production-oriented Doginex storefront.
- Responsive Persian RTL storefront.
- Real PHP/MySQL e-commerce core.
- Products, categories, coupons, orders and admin.
- ZarinPal v4 request/verify flow scaffolded for production configuration.
- Secure digital-file delivery.
- SEO foundation, sitemap and robots route.
- Installer and client documentation.

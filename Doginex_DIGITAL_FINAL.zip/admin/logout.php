<?php require __DIR__.'/../includes/bootstrap.php';$a=admin();if($a)log_event('logout','admin',(int)$a['id']);unset($_SESSION['admin']);session_regenerate_id(true);redirect(url('admin/login'));

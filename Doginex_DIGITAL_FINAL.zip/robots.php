<?php
require __DIR__.'/includes/bootstrap.php';
header('Content-Type: text/plain; charset=utf-8');
echo "User-agent: *\nAllow: /\nDisallow: /admin/\nDisallow: /storage/\nDisallow: /install.php\nSitemap: ".url('sitemap.xml')."\n";

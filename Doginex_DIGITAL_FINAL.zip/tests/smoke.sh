#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
COUNT=0
while IFS= read -r -d '' f; do php -l "$f" >/dev/null; COUNT=$((COUNT+1)); done < <(find "$ROOT" -name '*.php' -print0)
[[ -f "$ROOT/schema.sql" ]]
[[ -f "$ROOT/install.php" ]]
[[ -f "$ROOT/.htaccess" ]]
[[ -d "$ROOT/admin" ]]
echo "Doginex smoke checks passed for $COUNT PHP files."

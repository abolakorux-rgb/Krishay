#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PASS=0
FAIL=0
run(){ local n="$1"; shift; printf 'PASS %02d — %s\n' "$n" "$1"; }
fail(){ local n="$1"; shift; printf 'FAIL %02d — %s\n' "$n" "$1"; FAIL=$((FAIL+1)); }
record_pass(){ local n="$1"; shift; PASS=$((PASS+1)); run "$n" "$*"; }

# 1 PHP syntax for every PHP file
ok=1; while IFS= read -r -d '' f; do php -l "$f" >/dev/null 2>&1 || { ok=0; echo "  syntax: $f"; }; done < <(find "$ROOT" -type f -name '*.php' -print0)
[[ $ok -eq 1 ]] && record_pass 1 "PHP syntax passes for every PHP file" || fail 1 "PHP syntax errors found"

# 2 Required delivery files
required=(.htaccess index.php install.php schema.sql config.example.php includes/bootstrap.php includes/layout.php admin/index.php admin/login.php admin/logout.php storage/.htaccess tests/smoke.sh)
ok=1; for f in "${required[@]}"; do [[ -f "$ROOT/$f" ]] || { ok=0; echo "  missing: $f"; }; done
[[ $ok -eq 1 ]] && record_pass 2 "Required application/admin/installer/security files exist" || fail 2 "Required file missing"

# 3 No production secrets in package
if grep -RInE "(sk_live_|AKIA[0-9A-Z]{16}|-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----|password[[:space:]]*=[[:space:]]*['\"][^'\"]{8,})" "$ROOT" --exclude='qa15.sh' --exclude='README.md' --exclude='QA-REPORT.md' >/tmp/doginex_secret_scan 2>/dev/null; then cat /tmp/doginex_secret_scan; fail 3 "Potential secret-like literal found"; else record_pass 3 "No obvious production secret/key literals"; fi

# 4 Digital-only schema and core tables
ok=1
for x in users categories products product_images coupons orders order_items download_tokens reviews settings media audit_logs login_attempts newsletter_subscribers; do grep -q "CREATE TABLE IF NOT EXISTS $x" "$ROOT/schema.sql" || { echo "  missing table $x"; ok=0; }; done
for x in "type ENUM('digital')" "public_token" "expires_at" "paid_at" "reserved_count" "uq_review_user_product" "digital_file" "digital_link_snapshot"; do grep -q "$x" "$ROOT/schema.sql" || { echo "  missing schema marker $x"; ok=0; }; done
if grep -q "ENUM('digital','physical')\|stock_reserved\|stock INT" "$ROOT/schema.sql"; then echo "  legacy physical inventory schema still present"; ok=0; fi
[[ $ok -eq 1 ]] && record_pass 4 "Schema is digital-only with secure order/download primitives" || fail 4 "Schema is inconsistent with digital-only model"

# 5 Digital-only storefront/admin enforcement
ok=1
grep -q "p.type='digital'" "$ROOT/index.php" || ok=0
grep -q "p.type='digital'" "$ROOT/includes/bootstrap.php" || ok=0
grep -q "WHERE type='digital'" "$ROOT/admin/index.php" || ok=0
grep -q "type='digital'" "$ROOT/admin/index.php" || ok=0
grep -q "برای انتشار محصول دیجیتال" "$ROOT/admin/index.php" || ok=0
grep -q "digital_link_snapshot" "$ROOT/index.php" || ok=0
if grep -RniE "physical|فیزیکی|shipping_flat|هزینه ارسال|name=\"province\"|name=\"city\"|name=\"address\"|name=\"postal_code\"" --include='*.php' --include='*.html' "$ROOT" >/tmp/doginex_physical_refs 2>/dev/null; then cat /tmp/doginex_physical_refs; ok=0; fi
[[ $ok -eq 1 ]] && record_pass 5 "Storefront/cart/admin/checkout contain no physical-product flow" || fail 5 "Physical-product logic or UI remains"

# 6 CSRF enforcement
ok=1; grep -q "function require_csrf" "$ROOT/includes/bootstrap.php" || ok=0; grep -q "csrf_input" "$ROOT/index.php" || ok=0; grep -q "require_csrf" "$ROOT/admin/index.php" || ok=0; grep -q "require_csrf" "$ROOT/admin/login.php" || ok=0
[[ $ok -eq 1 ]] && record_pass 6 "CSRF enforcement exists on mutation paths" || fail 6 "CSRF coverage incomplete"

# 7 No obvious GET-driven SQL mutation
if grep -RInE "\$_GET[^;]*(DELETE|UPDATE|INSERT)|route=delete|action=delete" "$ROOT" --include='*.php' >/tmp/doginex_get_mut 2>/dev/null; then cat /tmp/doginex_get_mut; fail 7 "Potential GET-driven mutation detected"; else record_pass 7 "No obvious GET-driven SQL mutation paths"; fi

# 8 Secure digital download
ok=1; grep -q "hash_hmac('sha256'" "$ROOT/index.php" || ok=0; grep -q "download_count<max_downloads" "$ROOT/index.php" || ok=0; grep -q "payment_status.*paid" "$ROOT/index.php" || ok=0; grep -q "download_key" "$ROOT/install.php" || ok=0; [[ -f "$ROOT/storage/.htaccess" ]] || ok=0
if grep -q "base64_decode" "$ROOT/index.php"; then ok=0; fi
[[ $ok -eq 1 ]] && record_pass 8 "Download uses secret-backed token, paid-order gate, expiry and max-download counter" || fail 8 "Digital download hardening incomplete"

# 9 Cart integrity / server-side pricing
ok=1; grep -q "function cart_items" "$ROOT/includes/bootstrap.php" || ok=0; grep -q "function cart_subtotal" "$ROOT/includes/bootstrap.php" || ok=0; grep -q "SELECT p\.\*,c\.name category_name" "$ROOT/includes/bootstrap.php" || ok=0; grep -q "line_total" "$ROOT/includes/bootstrap.php" || ok=0
[[ $ok -eq 1 ]] && record_pass 9 "Cart is rebuilt from server-side product data and digital-only products" || fail 9 "Cart integrity incomplete"

# 10 RBAC
ok=1; grep -q "function admin_can" "$ROOT/includes/bootstrap.php" || ok=0; grep -q "require_permission" "$ROOT/admin/index.php" || ok=0; grep -q "'settings'=>\[\]" "$ROOT/includes/bootstrap.php" || ok=0; grep -q "'logs'=>\[\]" "$ROOT/includes/bootstrap.php" || ok=0
[[ $ok -eq 1 ]] && record_pass 10 "Role-based admin authorization map exists" || fail 10 "RBAC incomplete"

# 11 Upload security
ok=1; grep -q "getimagesize" "$ROOT/admin/index.php" || ok=0; grep -q "new finfo" "$ROOT/admin/index.php" || ok=0; grep -q "random_token" "$ROOT/admin/index.php" || ok=0; [[ -f "$ROOT/storage/.htaccess" ]] || ok=0
[[ $ok -eq 1 ]] && record_pass 11 "Image/file upload validation and protected digital storage present" || fail 11 "Upload hardening incomplete"

# 12 Authentication/password/session/rate-limit
ok=1; grep -q "password_verify" "$ROOT/admin/login.php" || ok=0; grep -q "login_attempts" "$ROOT/admin/login.php" || ok=0; grep -q "session_regenerate_id" "$ROOT/admin/login.php" "$ROOT/index.php" || ok=0; grep -q "password_hash" "$ROOT/admin/login.php" "$ROOT/index.php" || ok=0
[[ $ok -eq 1 ]] && record_pass 12 "Password verification, session rotation and throttling logic present" || fail 12 "Authentication hardening incomplete"

# 13 Customer/review/payment integrity
ok=1; grep -q "account.*register" "$ROOT/index.php" || ok=0; grep -q "payment_status='paid'" "$ROOT/index.php" || ok=0; grep -q "INSERT INTO reviews" "$ROOT/index.php" || ok=0; grep -q "uq_review_user_product" "$ROOT/schema.sql" || ok=0; grep -q "payment/request.json" "$ROOT/index.php" || ok=0; grep -q "payment/verify.json" "$ROOT/index.php" || ok=0
[[ $ok -eq 1 ]] && record_pass 13 "Customer/review flows and ZarinPal request/verify wiring are present" || fail 13 "Customer/review/payment integration incomplete"

# 14 Server hardening / installer
ok=1; grep -q "Options -Indexes" "$ROOT/.htaccess" || ok=0; grep -q "installed.lock" "$ROOT/install.php" || ok=0; grep -q "httponly" "$ROOT/includes/bootstrap.php" || ok=0; grep -q "nosniff" "$ROOT/index.php" || ok=0; grep -q "CURLOPT_SSL_VERIFYPEER=>true" "$ROOT/index.php" || ok=0
[[ $ok -eq 1 ]] && record_pass 14 "Apache/LiteSpeed hardening, installer lock, secure cookies and TLS verification present" || fail 14 "Server hardening incomplete"

# 15 Package/docs consistency
ok=1; [[ ! -f "$ROOT/config.php" ]] || ok=0; [[ ! -f "$ROOT/storage/installed.lock" ]] || ok=0; [[ -f "$ROOT/README.md" ]] || ok=0; [[ -f "$ROOT/docs/QA-REPORT.md" ]] || ok=0
if grep -RniE "فروش محصولات فیزیکی|فروش.*physical|shipping_flat|هزینه ارسال.*تنظیم|هزینه ارسال.*تکمیل|رزرو.*موجودی|oversell|stock_reserved" --include='*.md' "$ROOT/README.md" "$ROOT/docs" >/tmp/doginex_docs_refs 2>/dev/null; then cat /tmp/doginex_docs_refs; ok=0; fi
[[ $ok -eq 1 ]] && record_pass 15 "Package excludes live install state and docs match digital-only delivery" || fail 15 "Package/docs consistency issue"

printf '\nRESULT: %d/15 passes, %d failures\n' "$PASS" "$FAIL"
[[ $FAIL -eq 0 ]]

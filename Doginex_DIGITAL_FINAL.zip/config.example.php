<?php
return [
    'app_url' => 'https://example.com',
    'timezone' => 'Asia/Tehran',
    'db_host' => 'localhost',
    'db_name' => 'doginex',
    'db_user' => 'doginex',
    'db_pass' => '',
    'download_key' => 'GENERATED_DURING_INSTALL',
    'zarinpal_merchant' => '',
    'zarinpal_sandbox' => false,
    'mail_from' => 'no-reply@example.com',
];

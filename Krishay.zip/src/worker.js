import { DurableObject } from "cloudflare:workers";

const SITE_KEY = "site_data";
const CREDS_KEY = "credentials";
const STATE_KEY = "krishay_state_v2";
const SECRET_KEY = "session_secret";
const SESSION_TTL = 60 * 60 * 24 * 7;
const MAX_MEDIA_BYTES = 9 * 1024 * 1024;
const MAX_MESSAGES = 1000;

const defaultSiteData = () => ({
  site: {
    name: "KRISHAY",
    tagline: "استودیو دیجیتال برای برندهایی که دیده می‌شوند.",
    description: "طراحی سایت، هویت دیجیتال و تجربه کاربری با تمرکز روی نتیجه.",
    email: "hello@example.com",
    phone: "0912 000 0000",
    instagram: "",
    footer: "ساخته شده با دقت، برای برندهای جدی."
  },
  settings: { accent: "#00eaff" },
  categories: [
    { id: "cat1", name: "وب‌سایت" },
    { id: "cat2", name: "برندینگ" },
    { id: "cat3", name: "اپلیکیشن" }
  ],
  services: [
    { id: "s1", title: "طراحی وب‌سایت", text: "سایت‌های سریع، ریسپانسیو و حرفه‌ای با تمرکز روی تجربه کاربر.", icon: "01" },
    { id: "s2", title: "هویت بصری", text: "سیستم بصری منسجم برای اینکه برندت از هر زاویه قابل تشخیص باشد.", icon: "02" },
    { id: "s3", title: "تجربه محصول", text: "ساختاردهی و طراحی رابط برای محصولات دیجیتال مدرن.", icon: "03" }
  ],
  projects: [
    { id: "p1", title: "NOVA Commerce", category: "وب‌سایت", summary: "تجربه فروشگاهی سریع و مینیمال برای یک برند رو به رشد.", content: "یک نمونه پروژه با ساختار محتوایی کامل، صفحه معرفی و مسیر خرید ساده.", client: "NOVA", year: "2026", link: "", mediaIds: [] },
    { id: "p2", title: "LUMI Identity", category: "برندینگ", summary: "هویت بصری جسور و تمیز برای یک استارتاپ تکنولوژی.", content: "سیستم لوگو، رنگ و گرافیک دیجیتال با تمرکز بر مقیاس‌پذیری.", client: "LUMI", year: "2026", link: "", mediaIds: [] },
    { id: "p3", title: "MOTION App", category: "اپلیکیشن", summary: "داشبورد محصول با معماری اطلاعات ساده و قابل فهم.", content: "تجربه کاربری یک محصول SaaS با تمرکز بر وضوح و سرعت.", client: "MOTION", year: "2025", link: "", mediaIds: [] }
  ],
  pages: [
    { id: "pg1", slug: "about", title: "درباره ما", content: "ما روی تجربه‌های دیجیتال دقیق و قابل توسعه تمرکز می‌کنیم." },
    { id: "pg2", slug: "contact", title: "تماس", content: "برای شروع یک پروژه جدید پیام بفرستید." }
  ],
  messages: [],
  fileMeta: []
});

function json(obj, status = 200, headers = {}) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store, no-cache, must-revalidate", ...headers }
  });
}

function bytesToHex(bytes) { return [...bytes].map(b => b.toString(16).padStart(2, "0")).join(""); }
function hexToBytes(hex) {
  const out = new Uint8Array(hex.length / 2);
  for (let i = 0; i < out.length; i++) out[i] = parseInt(hex.substr(i * 2, 2), 16);
  return out;
}
function b64url(bytesOrStr) {
  const str = typeof bytesOrStr === "string" ? bytesOrStr : String.fromCharCode(...bytesOrStr);
  return btoa(str).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function b64urlDecodeToStr(s) {
  s = s.replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  return atob(s);
}
function timingSafeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

async function hashPassword(password, saltHex, iterations = 120000) {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey("raw", enc.encode(password), { name: "PBKDF2" }, false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", salt: hexToBytes(saltHex), iterations },
    keyMaterial,
    256
  );
  return bytesToHex(new Uint8Array(bits));
}

async function createDefaultCredentials() {
  const salt = bytesToHex(crypto.getRandomValues(new Uint8Array(16)));
  const iterations = 120000;
  const hash = await hashPassword("admin123", salt, iterations);
  return { email: "admin@example.com", salt, hash, iterations, v: 1 };
}

function getCookie(request, name) {
  const header = request.headers.get("cookie") || "";
  for (const part of header.split(";")) {
    const p = part.trim();
    if (p.startsWith(name + "=")) return p.slice(name.length + 1);
  }
  return null;
}
function sessionCookieHeader(token, maxAge) {
  return `session=${token}; Path=/api; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`;
}
function clearSessionCookieHeader() {
  return "session=; Path=/api; HttpOnly; Secure; SameSite=Lax; Max-Age=0";
}

function cleanState(data) {
  const fresh = defaultSiteData();
  const source = data && typeof data === "object" ? data : {};
  return {
    site: { ...fresh.site, ...(source.site || {}) },
    settings: { ...fresh.settings, ...(source.settings || {}) },
    categories: Array.isArray(source.categories) ? source.categories : fresh.categories,
    services: Array.isArray(source.services) ? source.services : fresh.services,
    projects: Array.isArray(source.projects) ? source.projects : fresh.projects,
    pages: Array.isArray(source.pages) ? source.pages : fresh.pages,
    messages: Array.isArray(source.messages) ? source.messages.slice(0, MAX_MESSAGES) : [],
    fileMeta: Array.isArray(source.fileMeta) ? source.fileMeta : []
  };
}

async function getAuthStub(env) {
  const id = env.AUTH.idFromName("krishay-global");
  return env.AUTH.get(id);
}
async function authCall(env, action, body = {}) {
  const stub = await getAuthStub(env);
  const res = await stub.fetch("https://internal/auth/" + action, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body)
  });
  let payload = null;
  try { payload = await res.json(); } catch (e) {}
  if (!res.ok) throw Object.assign(new Error((payload && payload.error) || "auth_failed"), { status: res.status });
  return payload;
}
async function requireSession(request, env) {
  const token = getCookie(request, "session");
  if (!token) return null;
  const result = await authCall(env, "verify", { token });
  return result && result.ok ? result.session : null;
}

async function handleLogin(request, env) {
  let body;
  try { body = await request.json(); } catch (e) { return json({ ok: false, error: "bad_request" }, 400); }
  const email = typeof body.email === "string" ? body.email.trim().toLowerCase().slice(0, 200) : "";
  const password = typeof body.password === "string" ? body.password : "";
  if (!email || !password) return json({ ok: false, error: "missing_fields" }, 400);
  const result = await authCall(env, "login", { email, password });
  if (!result.ok) return json(result, 401);
  return json({ ok: true }, 200, { "set-cookie": sessionCookieHeader(result.token, SESSION_TTL) });
}

async function handleAdminData(request, env) {
  const token = getCookie(request, "session");
  const result = await authCall(env, "data", { token });
  if (!result.ok) return json({ ok: false, error: "unauthorized" }, 401);
  return json({ ok: true, data: result.data });
}

async function handleAdminSave(request, env) {
  const token = getCookie(request, "session");
  let body;
  try { body = await request.json(); } catch (e) { return json({ ok: false, error: "bad_request" }, 400); }
  const allowed = ["site", "settings", "categories", "services", "projects", "pages", "messages", "fileMeta"];
  const patch = {};
  for (const key of allowed) if (body[key] !== undefined) patch[key] = body[key];
  const result = await authCall(env, "save", { token, patch });
  if (!result.ok) return json(result, 401);
  return json({ ok: true });
}

async function handleAdminCredentials(request, env) {
  const token = getCookie(request, "session");
  let body;
  try { body = await request.json(); } catch (e) { return json({ ok: false, error: "bad_request" }, 400); }
  const email = typeof body.email === "string" ? body.email.trim().toLowerCase().slice(0, 200) : "";
  const password = typeof body.password === "string" ? body.password : "";
  if (!/^\S+@\S+\.\S+$/.test(email) || password.length < 8 || password.length > 200) {
    return json({ ok: false, error: "invalid_input" }, 400);
  }
  const result = await authCall(env, "credentials", { token, email, password });
  if (!result.ok) return json(result, result.error === "unauthorized" ? 401 : 400);
  return json({ ok: true }, 200, { "set-cookie": sessionCookieHeader(result.token, SESSION_TTL) });
}

async function handlePublicData(env) {
  const result = await authCall(env, "public", {});
  return json(result.ok ? result.data : { site: defaultSiteData().site, settings: defaultSiteData().settings, categories: [], services: [], projects: [], pages: [] }, result.ok ? 200 : 503);
}

async function handleContact(request, env) {
  let body;
  try { body = await request.json(); } catch (e) { return json({ ok: false, error: "bad_request" }, 400); }
  const name = typeof body.name === "string" ? body.name.trim().slice(0, 150) : "";
  const email = typeof body.email === "string" ? body.email.trim().slice(0, 200) : "";
  const message = typeof body.message === "string" ? body.message.trim().slice(0, 4000) : "";
  if (!name || !email || !message) return json({ ok: false, error: "missing_fields" }, 400);
  const result = await authCall(env, "contact", { name, email, message });
  return json(result, result.ok ? 200 : 500);
}

async function handleMediaUpload(request, env) {
  const token = getCookie(request, "session");
  const verified = await authCall(env, "verify", { token });
  if (!verified.ok) return json({ ok: false, error: "unauthorized" }, 401);
  const form = await request.formData();
  const file = form.get("file");
  if (!file || typeof file === "string") return json({ ok: false, error: "no_file" }, 400);
  if (file.size <= 0) return json({ ok: false, error: "empty_file" }, 400);
  if (file.size > MAX_MEDIA_BYTES) return json({ ok: false, error: "file_too_large" }, 413);
  const id = "m_" + crypto.randomUUID().slice(0, 12);
  const buf = await file.arrayBuffer();
  await env.CMS_KV.put("media:" + id, buf, {
    metadata: { name: file.name, type: file.type || "application/octet-stream", size: file.size }
  });
  const meta = { id, name: file.name, type: file.type || "application/octet-stream", size: file.size };
  const result = await authCall(env, "add-media", { token, meta });
  if (!result.ok) {
    await env.CMS_KV.delete("media:" + id);
    return json({ ok: false, error: "unauthorized" }, 401);
  }
  return json({ ok: true, media: meta });
}

async function handleMediaDelete(id, request, env) {
  const token = getCookie(request, "session");
  const result = await authCall(env, "delete-media", { token, id });
  if (!result.ok) return json({ ok: false, error: "unauthorized" }, 401);
  await env.CMS_KV.delete("media:" + id);
  return json({ ok: true });
}

async function handleMediaGet(id, env) {
  const res = await env.CMS_KV.getWithMetadata("media:" + id, { type: "arrayBuffer" });
  if (!res || !res.value) return new Response("Not found", { status: 404 });
  const meta = res.metadata || {};
  return new Response(res.value, {
    status: 200,
    headers: {
      "content-type": meta.type || "application/octet-stream",
      "cache-control": "public, max-age=31536000, immutable",
      "x-content-type-options": "nosniff"
    }
  });
}

export class AuthDO extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.ctx = ctx;
    this.env = env;
  }

  async ensureInitialized() {
    let state = await this.ctx.storage.get("state");
    let creds = await this.ctx.storage.get("credentials");
    let secret = await this.ctx.storage.get(SECRET_KEY);

    if (!state) {
      let migrated = null;
      try { migrated = await this.env.CMS_KV.get(SITE_KEY, { type: "json" }); } catch (e) {}
      state = cleanState(migrated || defaultSiteData());
      await this.ctx.storage.put("state", state);
    } else {
      state = cleanState(state);
    }

    if (!creds) {
      let migratedCreds = null;
      try { migratedCreds = await this.env.CMS_KV.get(CREDS_KEY, { type: "json" }); } catch (e) {}
      if (migratedCreds && migratedCreds.email && migratedCreds.salt && migratedCreds.hash) {
        creds = { ...migratedCreds, email: String(migratedCreds.email).trim().toLowerCase(), iterations: Number(migratedCreds.iterations) || 100000, v: Number(migratedCreds.v) || 1 };
      } else {
        creds = await createDefaultCredentials();
      }
      await this.ctx.storage.put("credentials", creds);
    }

    if (!secret) {
      const bytes = crypto.getRandomValues(new Uint8Array(32));
      secret = bytesToHex(bytes);
      await this.ctx.storage.put(SECRET_KEY, secret);
    }

    return { state, creds, secret };
  }

  async signToken(payloadObj, secret) {
    const key = await crypto.subtle.importKey("raw", hexToBytes(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const payload = b64url(JSON.stringify(payloadObj));
    const sigBuf = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(payload));
    return `${payload}.${b64url(new Uint8Array(sigBuf))}`;
  }

  async verifyToken(token, creds, secret) {
    if (!token || !token.includes(".")) return null;
    const [payload, sig] = token.split(".");
    const key = await crypto.subtle.importKey("raw", hexToBytes(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const sigBuf = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(payload));
    const expected = b64url(new Uint8Array(sigBuf));
    if (!timingSafeEqual(expected, sig)) return null;
    try {
      const obj = JSON.parse(b64urlDecodeToStr(payload));
      if (!obj.exp || obj.exp < Date.now() || obj.v !== creds.v) return null;
      return obj;
    } catch (e) {
      return null;
    }
  }

  async requireToken(token, creds, secret) {
    if (!token) return false;
    return !!(await this.verifyToken(token, creds, secret));
  }

  async fetch(request) {
    const { state, creds, secret } = await this.ensureInitialized();
    const url = new URL(request.url);
    let body = {};
    try { body = await request.json(); } catch (e) {}
    const action = url.pathname.replace(/^\//, "");

    if (action === "public") {
      const { site, settings, categories, services, projects, pages } = state;
      return json({ ok: true, data: { site, settings, categories, services, projects, pages } });
    }

    if (action === "login") {
      const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
      const password = typeof body.password === "string" ? body.password : "";
      const hash = await hashPassword(password, creds.salt, creds.iterations);
      if (!timingSafeEqual(email, creds.email.toLowerCase()) || !timingSafeEqual(hash, creds.hash)) {
        return json({ ok: false, error: "invalid_credentials" }, 401);
      }
      const token = await this.signToken({ v: creds.v, exp: Date.now() + SESSION_TTL * 1000 }, secret);
      return json({ ok: true, token });
    }

    if (action === "contact") {
      const name = String(body.name || "").trim().slice(0, 150);
      const email = String(body.email || "").trim().slice(0, 200);
      const message = String(body.message || "").trim().slice(0, 4000);
      if (!name || !email || !message) return json({ ok: false, error: "missing_fields" }, 400);
      state.messages.unshift({
        id: "msg_" + crypto.randomUUID().slice(0, 12),
        name, email, message, createdAt: Date.now()
      });
      if (state.messages.length > MAX_MESSAGES) state.messages.length = MAX_MESSAGES;
      await this.ctx.storage.put("state", state);
      return json({ ok: true });
    }

    const authenticated = await this.requireToken(body.token, creds, secret);
    if (!authenticated) return json({ ok: false, error: "unauthorized" }, 401);

    if (action === "verify") return json({ ok: true, session: { email: creds.email } });

    if (action === "data") {
      return json({ ok: true, data: { ...state, adminEmail: creds.email } });
    }

    if (action === "save") {
      const allowed = ["site", "settings", "categories", "services", "projects", "pages", "messages", "fileMeta"];
      for (const key of allowed) if (body.patch && body.patch[key] !== undefined) state[key] = body.patch[key];
      state = cleanState(state);
      await this.ctx.storage.put("state", state);
      return json({ ok: true });
    }

    if (action === "credentials") {
      const email = String(body.email || "").trim().toLowerCase();
      const password = typeof body.password === "string" ? body.password : "";
      const salt = bytesToHex(crypto.getRandomValues(new Uint8Array(16)));
      const hash = await hashPassword(password, salt, 120000);
      const nextV = (Number(creds.v) || 1) + 1;
      const nextCreds = { email, salt, hash, iterations: 120000, v: nextV };
      await this.ctx.storage.put("credentials", nextCreds);
      const token = await this.signToken({ v: nextV, exp: Date.now() + SESSION_TTL * 1000 }, secret);
      return json({ ok: true, token });
    }

    if (action === "add-media") {
      state.fileMeta.push(body.meta);
      await this.ctx.storage.put("state", state);
      return json({ ok: true });
    }

    if (action === "delete-media") {
      const id = String(body.id || "");
      state.fileMeta = state.fileMeta.filter(x => x.id !== id);
      state.projects.forEach(p => { p.mediaIds = (p.mediaIds || []).filter(x => x !== id); });
      await this.ctx.storage.put("state", state);
      return json({ ok: true });
    }

    return json({ ok: false, error: "not_found" }, 404);
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;
    try {
      if (path === "/api/public/data" && method === "GET") return await handlePublicData(env);
      if (path === "/api/contact" && method === "POST") return await handleContact(request, env);
      if (path === "/api/login" && method === "POST") return await handleLogin(request, env);
      if (path === "/api/logout" && method === "POST") return json({ ok: true }, 200, { "set-cookie": clearSessionCookieHeader() });
      if (path === "/api/admin/data" && method === "GET") return await handleAdminData(request, env);
      if (path === "/api/admin/save" && method === "POST") return await handleAdminSave(request, env);
      if (path === "/api/admin/credentials" && method === "POST") return await handleAdminCredentials(request, env);
      if (path === "/api/admin/media" && method === "POST") return await handleMediaUpload(request, env);
      if (path.startsWith("/api/admin/media/") && method === "DELETE") {
        return await handleMediaDelete(decodeURIComponent(path.slice("/api/admin/media/".length)), request, env);
      }
      if (path.startsWith("/api/media/") && method === "GET") {
        return await handleMediaGet(decodeURIComponent(path.slice("/api/media/".length)), env);
      }
      if (path.startsWith("/api/")) return json({ ok: false, error: "not_found" }, 404);
      return env.ASSETS.fetch(request);
    } catch (err) {
      console.error(err);
      return json({ ok: false, error: "server_error" }, 500);
    }
  }
};

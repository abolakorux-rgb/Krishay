(() => {
  let data = null;
  let currentAdminSection = "dashboard";

  function esc(s = "") { return String(s).replace(/[&<>"']/g, m => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#039;" }[m])); }
  function uid(prefix = "id") { return prefix + "_" + Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4); }
  function mediaUrl(id) { return id ? `/api/media/${encodeURIComponent(id)}` : ""; }

  async function api(path, method, body) {
    const opts = { method, credentials: "same-origin", headers: {} };
    if (body !== undefined) {
      opts.headers["content-type"] = "application/json";
      opts.body = JSON.stringify(body);
    }
    const res = await fetch(path, opts);
    let payload = null;
    try { payload = await res.json(); } catch (e) {}
    if (!res.ok || (payload && payload.ok === false)) {
      const err = new Error((payload && payload.error) || "request_failed");
      err.status = res.status;
      throw err;
    }
    return payload;
  }

  async function loadPublicData() { data = await api("/api/public/data", "GET"); }

  let saveQueue = Promise.resolve();
  function save() {
    const snapshot = {
      site: structuredClone(data.site), settings: structuredClone(data.settings), categories: structuredClone(data.categories),
      services: structuredClone(data.services), projects: structuredClone(data.projects), pages: structuredClone(data.pages),
      messages: structuredClone(data.messages), fileMeta: structuredClone(data.fileMeta)
    };
    const task = saveQueue.catch(() => {}).then(() => api("/api/admin/save", "POST", snapshot));
    saveQueue = task;
    return task.catch(e => { toast("ذخیره‌سازی انجام نشد. اتصال را بررسی کن.", false); throw e; });
  }

  async function putMedia(file) {
    const fd = new FormData();
    fd.append("file", file);
    const res = await fetch("/api/admin/media", { method: "POST", credentials: "same-origin", body: fd });
    const j = await res.json().catch(() => null);
    if (!res.ok || !j || !j.ok) throw new Error((j && j.error) || "upload_failed");
    return j.media;
  }
  async function deleteMedia(id) {
    await api("/api/admin/media/" + encodeURIComponent(id), "DELETE");
    data.fileMeta = data.fileMeta.filter(x => x.id !== id);
    data.projects.forEach(p => { p.mediaIds = (p.mediaIds || []).filter(x => x !== id); });
  }

  function toast(msg, good = true) {
    const t = document.createElement("div");
    t.style.cssText = "position:fixed;bottom:18px;right:18px;z-index:999;background:" + (good ? "#071228" : "#8a1730") + ";color:#fff;padding:12px 16px;border-radius:14px;box-shadow:0 15px 30px rgba(0,0,0,.2);max-width:320px";
    t.textContent = msg; document.body.appendChild(t); setTimeout(() => t.remove(), 2400);
  }

  function header() {
    return `<div class="topbar"><div class="container nav">
      <a class="logo" href="/">${esc(data.site.name)}<span>.</span></a>
      <div class="navlinks"><a href="/#work">نمونه‌کارها</a><a href="/#services">خدمات</a><a href="/#about">درباره</a><a href="/#contact">تماس</a></div>
      <a class="btn neon" href="/admin/">مدیریت سایت</a>
    </div></div>`;
  }

  function home() {
    const projects = data.projects;
    document.querySelector("#app").innerHTML = `${header()}
      <main>
        <section class="hero"><div class="container hero-grid">
          <div><span class="kicker">طراحی دیجیتال با استاندارد حرفه‌ای</span>
            <h1>${esc(data.site.tagline)}</h1>
            <p>${esc(data.site.description)}</p>
            <div class="actions"><a class="btn neon" href="#work">مشاهده نمونه‌کارها</a><a class="btn ghost" href="#contact">شروع گفتگو</a></div>
          </div>
          <div class="hero-card"><div style="position:relative;z-index:2"><div class="kicker" style="color:#bafaff">KRISHAY STUDIO</div>
            <h2 style="font-size:34px;margin:12px 0 4px">تمرکز روی جزئیات.<br/>اثرگذاری روی نتیجه.</h2>
            <p style="color:#c9d8f0">ساخت تجربه‌هایی که هم زیبا هستند و هم قابل استفاده و توسعه.</p>
            <div class="metric"><div><small>پروژه‌ها</small><strong>${projects.length}</strong></div><div><small>دسته‌ها</small><strong>${data.categories.length}</strong></div></div>
          </div></div>
        </div></section>
        <section class="section" id="work"><div class="container">
          <div class="section-head"><div><h2>نمونه‌کارها</h2><p>چند پروژه از مجموعه کارها.</p></div></div>
          <div class="grid portfolio-grid">${projects.map(projectCard).join("") || '<div class="empty">هنوز نمونه‌کاری اضافه نشده است.</div>'}</div>
        </div></section>
        <section class="section" id="services"><div class="container">
          <div class="section-head"><div><h2>خدمات</h2><p>از ایده تا اجرای نهایی.</p></div></div>
          <div class="grid service-grid">${data.services.map(s => `<div class="service"><div class="icon">${esc(s.icon)}</div><h3>${esc(s.title)}</h3><p style="color:var(--muted)">${esc(s.text)}</p></div>`).join("")}</div>
        </div></section>
        <section class="section" id="about"><div class="container"><div class="cta"><div><div class="kicker" style="color:#bafaff">ABOUT</div><h2 style="font-size:34px;margin:8px 0">${esc(data.site.name)} برای ساختن یک حضور دیجیتال متمایز.</h2><p style="color:#c9d8f0;max-width:650px;margin:0">${esc(data.pages.find(x => x.slug === "about")?.content || "")}</p></div><a class="btn neon" href="#contact">ارتباط</a></div></div></section>
        <section class="section" id="contact"><div class="container"><div class="section-head"><div><h2>شروع یک پروژه</h2><p>پیامت را بفرست؛ اطلاعات در پنل مدیریت ذخیره می‌شود.</p></div></div>
          <form id="contactForm" class="panel" style="max-width:760px"><div class="form-grid">
            <div class="field"><label>نام</label><input name="name" required></div>
            <div class="field"><label>ایمیل</label><input name="email" type="email" required></div>
            <div class="field full"><label>پیام</label><textarea name="message" required></textarea></div>
            <div><button class="btn neon" type="submit">ارسال پیام</button></div>
          </div></form>
        </div></section>
      </main>
      <footer class="footer"><div class="container">${esc(data.site.footer)}</div></footer>`;
    document.querySelector("#contactForm").onsubmit = async e => {
      e.preventDefault();
      const f = new FormData(e.currentTarget);
      const btn = e.currentTarget.querySelector("button");
      btn.disabled = true;
      try {
        await api("/api/contact", "POST", { name: f.get("name"), email: f.get("email"), message: f.get("message") });
        e.currentTarget.reset();
        toast("پیام با موفقیت ارسال شد.");
      } catch (err) { toast("ارسال پیام ناموفق بود. دوباره تلاش کن.", false); }
      btn.disabled = false;
    };
  }

  function projectCard(p) {
    const first = (p.mediaIds || [])[0], src = mediaUrl(first);
    return `<a class="card" href="/project/?id=${encodeURIComponent(p.id)}"><div class="thumb">${src ? `<img src="${src}" alt="${esc(p.title)}">` : `<div style="height:100%;display:grid;place-items:center;color:#fff;font-weight:900;font-size:30px">${esc(p.title.slice(0, 1))}</div>`}</div><div class="card-body"><span class="tag">${esc(p.category)}</span><h3>${esc(p.title)}</h3><p>${esc(p.summary)}</p></div></a>`;
  }

  function projectPage() {
    const id = new URLSearchParams(location.search).get("id");
    const p = data.projects.find(x => x.id === id);
    if (!p) { document.querySelector("#app").innerHTML = `${header()}<div class="container section"><div class="empty">پروژه پیدا نشد.</div></div>`; return; }
    const media = (p.mediaIds || []).map(mid => mediaUrl(mid)).filter(Boolean);
    document.querySelector("#app").innerHTML = `${header()}<main class="project-hero"><div class="container">
      <a class="back" href="/#work">← بازگشت به نمونه‌کارها</a><h1 style="font-size:56px;margin:15px 0">${esc(p.title)}</h1><p style="max-width:760px;color:var(--muted);font-size:18px">${esc(p.summary)}</p>
      <div class="project-layout" style="margin-top:28px"><article class="project-main">
        ${media.length ? media.map(src => `<img src="${src}" style="border-radius:18px;margin-bottom:14px" alt="">`).join("") : ""}
        <div style="font-size:16px">${esc(p.content).replace(/\n/g, "<br/>")}</div>
      </article><aside class="project-aside">
        <div class="detail-box"><strong>دسته‌بندی</strong><span>${esc(p.category)}</span></div>
        <div class="detail-box"><strong>مشتری</strong><span>${esc(p.client || "—")}</span></div>
        <div class="detail-box"><strong>سال</strong><span>${esc(p.year || "—")}</span></div>
        ${p.link ? `<a class="btn neon" target="_blank" href="${esc(p.link)}">مشاهده پروژه</a>` : ""}
      </aside></div></div></main><footer class="footer"><div class="container">${esc(data.site.footer)}</div></footer>`;
  }

  function login() {
    document.querySelector("#app").innerHTML = `<div class="login"><form class="login-card" id="loginForm"><div class="logo">KRISHAY<span style="color:#00a9d1">.</span></div><h1>ورود مدیر</h1><p class="help">مدیریت نمونه‌کارها، محتوا، رسانه‌ها و تنظیمات سایت.</p>
      <div class="field" style="margin-top:18px"><label>ایمیل مدیر</label><input name="email" type="email" required placeholder="admin@example.com"></div>
      <div class="field" style="margin-top:12px"><label>رمز عبور</label><input name="password" type="password" required></div>
      <button class="btn neon" style="width:100%;margin-top:18px">ورود</button><p class="help" style="margin-top:12px">ورود شما روی همهٔ دستگاه‌ها معتبر است.</p>
    </form></div>`;
    document.querySelector("#loginForm").onsubmit = async e => {
      e.preventDefault();
      const f = new FormData(e.currentTarget);
      const btn = e.currentTarget.querySelector("button");
      btn.disabled = true;
      try {
        await api("/api/login", "POST", { email: f.get("email"), password: f.get("password") });
        location.href = "/admin/";
      } catch (err) { toast("ایمیل یا رمز عبور نادرست است.", false); btn.disabled = false; }
    };
  }

  function sidebar() {
    const items = [["dashboard", "داشبورد"], ["projects", "نمونه‌کارها"], ["categories", "دسته‌بندی‌ها"], ["services", "خدمات"], ["pages", "صفحات"], ["media", "رسانه‌ها"], ["messages", "پیام‌ها"], ["settings", "تنظیمات"]];
    return `<aside class="sidebar" id="sidebar"><div class="side-logo">${esc(data.site.name)}<span>.</span></div><div class="side-nav">${items.map(([k, t]) => `<button class="${currentAdminSection === k ? "active" : ""}" data-sec="${k}">${t}</button>`).join("")}<button id="logout">خروج</button></div></aside>`;
  }

  async function admin() {
    let res;
    try { res = await api("/api/admin/data", "GET"); }
    catch (e) {
      if (e.status === 401) { login(); return; }
      document.querySelector("#app").innerHTML = `<div class="container section"><div class="empty">خطا در برقراری ارتباط با سرور.</div></div>`;
      return;
    }
    data = res.data;
    document.querySelector("#app").innerHTML = `<div class="admin-shell">${sidebar()}<main class="admin-main"><div class="admin-top"><div style="display:flex;gap:10px;align-items:center"><button class="btn ghost mobile-side-btn" id="sideBtn">☰</button><h1>${sectionTitle()}</h1></div><a class="btn neon small" href="/" target="_blank">مشاهده سایت</a></div><div id="adminContent"></div></main></div>`;
    document.querySelectorAll("[data-sec]").forEach(b => b.onclick = () => { currentAdminSection = b.dataset.sec; admin(); });
    document.querySelector("#logout").onclick = async () => { try { await api("/api/logout", "POST"); } catch (e) {} location.href = "/admin/"; };
    document.querySelector("#sideBtn")?.addEventListener("click", () => document.querySelector("#sidebar").classList.toggle("open"));
    renderAdminSection();
  }
  function sectionTitle() { return ({ dashboard: "داشبورد", projects: "نمونه‌کارها", categories: "دسته‌بندی‌ها", services: "خدمات", pages: "صفحات", media: "رسانه‌ها", messages: "پیام‌ها", settings: "تنظیمات" })[currentAdminSection] || "مدیریت"; }

  function renderAdminSection() {
    const c = document.querySelector("#adminContent");
    if (currentAdminSection === "dashboard") {
      c.innerHTML = `<div class="admin-grid">
        <div class="stat"><small>نمونه‌کارها</small><strong>${data.projects.length}</strong></div>
        <div class="stat"><small>دسته‌بندی‌ها</small><strong>${data.categories.length}</strong></div>
        <div class="stat"><small>رسانه‌ها</small><strong>${data.fileMeta.length}</strong></div>
        <div class="stat"><small>پیام‌ها</small><strong>${data.messages.length}</strong></div>
      </div>
      <div class="panel"><h2>دسترسی سریع</h2><div class="actions"><button class="btn neon" data-sec2="projects">افزودن نمونه‌کار</button><button class="btn ghost" data-sec2="media">آپلود رسانه</button><button class="btn ghost" data-sec2="settings">تنظیمات مدیر</button></div></div>
      <div class="panel"><h2>آخرین پیام‌ها</h2>${data.messages.slice(0, 5).map(m => `<div style="padding:12px 0;border-bottom:1px solid var(--line)"><strong>${esc(m.name)}</strong><div class="help">${esc(m.email)} — ${new Date(m.createdAt).toLocaleString("fa-IR")}</div><div>${esc(m.message)}</div></div>`).join("") || '<div class="empty">هنوز پیامی ندارید.</div>'}</div>`;
      c.querySelectorAll("[data-sec2]").forEach(b => b.onclick = () => { currentAdminSection = b.dataset.sec2; admin(); });
    } else if (currentAdminSection === "projects") { renderProjects(c); }
    else if (currentAdminSection === "categories") { renderCategories(c); }
    else if (currentAdminSection === "services") { renderServices(c); }
    else if (currentAdminSection === "pages") { renderPages(c); }
    else if (currentAdminSection === "media") { renderMedia(c); }
    else if (currentAdminSection === "messages") { renderMessages(c); }
    else if (currentAdminSection === "settings") { renderSettings(c); }
  }

  function renderProjects(c) {
    c.innerHTML = `<div class="panel"><div class="toolbar"><strong>نمونه‌کارها</strong><button class="btn neon small" id="addProject">+ نمونه‌کار جدید</button></div><div class="table-wrap"><table><thead><tr><th>عنوان</th><th>دسته</th><th>مشتری</th><th>سال</th><th>عملیات</th></tr></thead><tbody>${data.projects.map(p => `<tr><td><strong>${esc(p.title)}</strong><div class="help">${esc(p.summary)}</div></td><td>${esc(p.category)}</td><td>${esc(p.client)}</td><td>${esc(p.year)}</td><td><button class="btn small ghost" data-edit="${p.id}">ویرایش</button> <button class="btn small danger" data-del="${p.id}">حذف</button></td></tr>`).join("")}</tbody></table></div></div>`;
    c.querySelector("#addProject").onclick = () => openProjectModal();
    c.querySelectorAll("[data-edit]").forEach(b => b.onclick = () => openProjectModal(data.projects.find(x => x.id === b.dataset.edit)));
    c.querySelectorAll("[data-del]").forEach(b => b.onclick = () => { if (confirm("این نمونه‌کار حذف شود؟")) { data.projects = data.projects.filter(x => x.id !== b.dataset.del); save().then(() => admin()).catch(() => {}); } });
  }
  function openProjectModal(p = null) {
    const cats = data.categories.map(x => `<option ${p?.category === x.name ? "selected" : ""}>${esc(x.name)}</option>`).join("");
    const ids = p?.mediaIds || [];
    const mediaChoices = data.fileMeta.map(m => `<label style="display:flex;align-items:center;gap:8px;border:1px solid var(--line);padding:8px;border-radius:12px"><input type="checkbox" name="media" value="${m.id}" ${ids.includes(m.id) ? "checked" : ""}><img src="${mediaUrl(m.id)}" style="width:42px;height:42px;object-fit:cover;border-radius:8px"><span class="help">${esc(m.name || "فایل")}</span></label>`).join("");
    const bg = document.createElement("div"); bg.className = "modal-backdrop show"; bg.innerHTML = `<div class="modal"><div class="toolbar"><h2 style="margin:0">${p ? "ویرایش" : "افزودن"} نمونه‌کار</h2><button class="btn ghost small" id="close">بستن</button></div>
      <form id="pf"><div class="form-grid">
      <div class="field"><label>عنوان</label><input name="title" required value="${esc(p?.title || "")}"></div>
      <div class="field"><label>دسته‌بندی</label><select name="category">${cats}</select></div>
      <div class="field"><label>نام مشتری</label><input name="client" value="${esc(p?.client || "")}"></div>
      <div class="field"><label>سال</label><input name="year" value="${esc(p?.year || "2026")}"></div>
      <div class="field full"><label>خلاصه</label><input name="summary" value="${esc(p?.summary || "")}"></div>
      <div class="field full"><label>توضیحات کامل</label><textarea name="content">${esc(p?.content || "")}</textarea></div>
      <div class="field full"><label>لینک پروژه</label><input name="link" placeholder="https://" value="${esc(p?.link || "")}"></div>
      <div class="field full"><label>رسانه‌های این پروژه</label><div class="grid" style="grid-template-columns:repeat(2,1fr)">${mediaChoices || '<div class="empty">اول چند فایل در بخش رسانه‌ها آپلود کن.</div>'}</div></div>
      </div><button class="btn neon" style="margin-top:16px">ذخیره</button></form></div>`;
    document.body.appendChild(bg); bg.querySelector("#close").onclick = () => bg.remove();
    bg.querySelector("#pf").onsubmit = e => {
      e.preventDefault();
      const f = new FormData(e.currentTarget);
      const obj = { id: p?.id || uid("p"), title: f.get("title"), category: f.get("category"), client: f.get("client"), year: f.get("year"), summary: f.get("summary"), content: f.get("content"), link: f.get("link"), mediaIds: [...bg.querySelectorAll('input[name="media"]:checked')].map(x => x.value) };
      if (p) { data.projects = data.projects.map(x => x.id === p.id ? obj : x); } else { data.projects.unshift(obj); }
      save().then(() => admin()).catch(() => {}); bg.remove();
    };
  }

  function renderCategories(c) {
    c.innerHTML = `<div class="panel"><div class="toolbar"><strong>دسته‌بندی‌ها</strong><button class="btn neon small" id="addCat">+ دسته جدید</button></div>${data.categories.map(x => `<div style="display:flex;justify-content:space-between;align-items:center;padding:12px 0;border-bottom:1px solid var(--line)"><span>${esc(x.name)}</span><button class="btn small danger" data-del="${x.id}">حذف</button></div>`).join("")}</div>`;
    c.querySelector("#addCat").onclick = () => { const n = prompt("نام دسته:"); if (n) { data.categories.push({ id: uid("cat"), name: n }); save().then(() => admin()).catch(() => {}); } };
    c.querySelectorAll("[data-del]").forEach(b => b.onclick = () => { data.categories = data.categories.filter(x => x.id !== b.dataset.del); save().then(() => admin()).catch(() => {}); });
  }

  function renderServices(c) {
    c.innerHTML = `<div class="panel"><div class="toolbar"><strong>خدمات</strong><button class="btn neon small" id="addService">+ خدمت جدید</button></div>${data.services.map(s => `<div style="display:grid;grid-template-columns:1fr auto;gap:12px;padding:14px 0;border-bottom:1px solid var(--line)"><div><strong>${esc(s.title)}</strong><div class="help">${esc(s.text)}</div></div><div><button class="btn small ghost" data-edit="${s.id}">ویرایش</button> <button class="btn small danger" data-del="${s.id}">حذف</button></div></div>`).join("")}</div>`;
    c.querySelector("#addService").onclick = () => openService();
    c.querySelectorAll("[data-edit]").forEach(b => b.onclick = () => openService(data.services.find(x => x.id === b.dataset.edit)));
    c.querySelectorAll("[data-del]").forEach(b => b.onclick = () => { data.services = data.services.filter(x => x.id !== b.dataset.del); save().then(() => admin()).catch(() => {}); });
  }
  function openService(s = null) {
    const bg = document.createElement("div"); bg.className = "modal-backdrop show"; bg.innerHTML = `<div class="modal"><div class="toolbar"><h2 style="margin:0">${s ? "ویرایش" : "افزودن"} خدمت</h2><button class="btn ghost small" id="close">بستن</button></div><form id="sf"><div class="form-grid">
      <div class="field"><label>عنوان</label><input name="title" required value="${esc(s?.title || "")}"></div>
      <div class="field"><label>شماره/آیکن</label><input name="icon" value="${esc(s?.icon || "01")}"></div>
      <div class="field full"><label>توضیح</label><textarea name="text">${esc(s?.text || "")}</textarea></div>
      </div><button class="btn neon" style="margin-top:16px">ذخیره</button></form></div>`;
    document.body.appendChild(bg); bg.querySelector("#close").onclick = () => bg.remove();
    bg.querySelector("#sf").onsubmit = e => { e.preventDefault(); const f = new FormData(e.currentTarget); const obj = { id: s?.id || uid("s"), title: f.get("title"), icon: f.get("icon"), text: f.get("text") }; data.services = s ? data.services.map(x => x.id === s.id ? obj : x) : [...data.services, obj]; save().then(() => admin()).catch(() => {}); bg.remove(); };
  }
  function renderPages(c) {
    c.innerHTML = `<div class="panel"><div class="toolbar"><strong>صفحات محتوایی</strong><button class="btn neon small" id="addPage">+ صفحه جدید</button></div>${data.pages.map(p => `<div style="padding:14px 0;border-bottom:1px solid var(--line)"><div style="display:flex;justify-content:space-between;gap:12px"><div><strong>${esc(p.title)}</strong><div class="help">/${esc(p.slug)}</div></div><button class="btn small ghost" data-edit="${p.id}">ویرایش</button></div><div style="margin-top:7px;color:var(--muted)">${esc(p.content)}</div></div>`).join("")}</div>`;
    c.querySelector("#addPage").onclick = () => openPage();
    c.querySelectorAll("[data-edit]").forEach(b => b.onclick = () => openPage(data.pages.find(x => x.id === b.dataset.edit)));
  }
  function openPage(p = null) {
    const bg = document.createElement("div"); bg.className = "modal-backdrop show"; bg.innerHTML = `<div class="modal"><div class="toolbar"><h2 style="margin:0">${p ? "ویرایش" : "افزودن"} صفحه</h2><button class="btn ghost small" id="close">بستن</button></div><form id="pgf"><div class="form-grid">
      <div class="field"><label>عنوان</label><input name="title" required value="${esc(p?.title || "")}"></div>
      <div class="field"><label>نام مسیر (slug)</label><input name="slug" required value="${esc(p?.slug || "")}"></div>
      <div class="field full"><label>محتوا</label><textarea name="content">${esc(p?.content || "")}</textarea></div></div><button class="btn neon" style="margin-top:16px">ذخیره</button></form></div>`;
    document.body.appendChild(bg); bg.querySelector("#close").onclick = () => bg.remove();
    bg.querySelector("#pgf").onsubmit = e => { e.preventDefault(); const f = new FormData(e.currentTarget); const obj = { id: p?.id || uid("pg"), title: f.get("title"), slug: f.get("slug"), content: f.get("content") }; data.pages = p ? data.pages.map(x => x.id === p.id ? obj : x) : [...data.pages, obj]; save().then(() => admin()).catch(() => {}); bg.remove(); };
  }
  function renderMedia(c) {
    c.innerHTML = `<div class="panel"><div class="toolbar"><strong>کتابخانه رسانه</strong><label class="btn neon small">+ آپلود فایل<input id="upload" type="file" multiple style="display:none"></label></div><div class="notice">فایل‌ها روی سرور نگه‌داری می‌شوند و در همهٔ دستگاه‌ها یکسان نمایش داده می‌شوند.</div><div class="media-grid" style="margin-top:16px">${data.fileMeta.map(m => `<div class="media-item"><div class="media-thumb">${m.type.startsWith("image/") ? `<img src="${mediaUrl(m.id)}" style="width:100%;height:100%;object-fit:cover">` : m.type.startsWith("video/") ? `<video src="${mediaUrl(m.id)}" muted></video>` : "📄"}</div><div class="meta"><div style="font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(m.name)}</div><div>${(m.size / 1024 / 1024).toFixed(2)} MB</div><button class="btn small danger" style="margin-top:8px" data-del="${m.id}">حذف</button></div></div>`).join("")}</div></div>`;
    c.querySelector("#upload").onchange = async e => {
      for (const file of e.target.files) {
        try { const meta = await putMedia(file); data.fileMeta.push(meta); }
        catch (err) { toast("آپلود «" + file.name + "» ناموفق بود.", false); }
      }
      save().then(() => admin()).catch(() => {});
    };
    c.querySelectorAll("[data-del]").forEach(b => b.onclick = async () => {
      if (!confirm("فایل حذف شود؟")) return;
      try { await deleteMedia(b.dataset.del); admin(); }
      catch (err) { toast("حذف فایل ناموفق بود.", false); }
    });
  }
  function renderMessages(c) {
    c.innerHTML = `<div class="panel"><div class="toolbar"><strong>پیام‌های تماس</strong><button class="btn small danger" id="clearMsgs">پاک‌سازی همه</button></div>${data.messages.map(m => `<div style="padding:15px 0;border-bottom:1px solid var(--line)"><div style="display:flex;justify-content:space-between;gap:12px"><strong>${esc(m.name)}</strong><span class="help">${new Date(m.createdAt).toLocaleString("fa-IR")}</span></div><div class="help">${esc(m.email)}</div><p style="margin-bottom:0">${esc(m.message)}</p></div>`).join("") || '<div class="empty">پیامی وجود ندارد.</div>'}</div>`;
    c.querySelector("#clearMsgs").onclick = () => { if (confirm("همه پیام‌ها حذف شوند؟")) { data.messages = []; save().then(() => admin()).catch(() => {}); } };
  }
  function renderSettings(c) {
    c.innerHTML = `<div class="panel"><h2>اطلاعات سایت</h2><form id="siteSettings"><div class="form-grid">
      <div class="field"><label>نام سایت</label><input name="name" value="${esc(data.site.name)}"></div>
      <div class="field"><label>ایمیل سایت</label><input name="email" value="${esc(data.site.email)}"></div>
      <div class="field full"><label>شعار</label><input name="tagline" value="${esc(data.site.tagline)}"></div>
      <div class="field full"><label>توضیح</label><textarea name="description">${esc(data.site.description)}</textarea></div>
      <div class="field"><label>تلفن</label><input name="phone" value="${esc(data.site.phone)}"></div>
      <div class="field"><label>اینستاگرام</label><input name="instagram" value="${esc(data.site.instagram)}"></div>
      <div class="field full"><label>متن فوتر</label><input name="footer" value="${esc(data.site.footer)}"></div>
      </div><button class="btn neon" style="margin-top:16px">ذخیره اطلاعات سایت</button></form></div>
      <div class="panel"><h2>ایمیل و رمز مدیر</h2><form id="cred"><div class="form-grid">
        <div class="field"><label>ایمیل جدید</label><input name="email" type="email" required value="${esc(data.adminEmail)}"></div>
        <div class="field"><label>رمز جدید</label><input name="password" type="password" minlength="8" autocomplete="new-password" required></div>
      </div><div class="help" style="margin-top:8px">برای حفظ امنیت، رمز را حداقل ۸ کاراکتر انتخاب کن. این تغییر روی همهٔ دستگاه‌ها اعمال می‌شود.</div><button class="btn neon" style="margin-top:16px">ذخیره ایمیل و رمز</button></form></div>
      <div class="panel"><h2>پشتیبان‌گیری</h2><p class="help">خروجی شامل محتوای سایت است (نمونه‌کارها، دسته‌ها، خدمات، صفحات، تنظیمات و پیام‌ها). فایل‌های رسانه روی سرور نگه‌داری می‌شوند و نیازی به انتقال دستی ندارند.</p><div class="actions"><button class="btn neon" id="export">خروجی کامل</button><label class="btn ghost">ورود اطلاعات<input id="import" type="file" accept=".json" style="display:none"></label></div></div>`;
    c.querySelector("#siteSettings").onsubmit = async e => { e.preventDefault(); const f = new FormData(e.currentTarget); data.site = { ...data.site, name: f.get("name"), email: f.get("email"), tagline: f.get("tagline"), description: f.get("description"), phone: f.get("phone"), instagram: f.get("instagram"), footer: f.get("footer") }; try { await save(); toast("اطلاعات سایت ذخیره شد."); } catch (err) {} };
    c.querySelector("#cred").onsubmit = async e => {
      e.preventDefault();
      const f = new FormData(e.currentTarget);
      try {
        await api("/api/admin/credentials", "POST", { email: f.get("email"), password: f.get("password") });
        data.adminEmail = f.get("email");
        e.currentTarget.reset();
        toast("ایمیل و رمز مدیر تغییر کرد.");
        admin();
      } catch (err) { toast("تغییر ایمیل/رمز ناموفق بود.", false); }
    };
    c.querySelector("#export").onclick = exportAll;
    c.querySelector("#import").onchange = importAll;
  }
  function exportAll() {
    const out = {
      data: { site: data.site, settings: data.settings, categories: data.categories, services: data.services, projects: data.projects, pages: data.pages, messages: data.messages, fileMeta: data.fileMeta },
      exportedAt: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(out)], { type: "application/json" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `krishay-backup-${Date.now()}.json`; a.click();
    toast("پشتیبان ساخته شد.");
  }
  async function importAll(e) {
    const f = e.target.files[0]; if (!f) return;
    try {
      const obj = JSON.parse(await f.text()); if (!obj.data) throw new Error();
      await api("/api/admin/save", "POST", obj.data);
      toast("اطلاعات بازیابی شد.");
      admin();
    } catch (err) { toast("فایل پشتیبان معتبر نیست.", false); }
  }

  (async () => {
    const page = document.body.dataset.page;
    if (page === "home") { await loadPublicData(); home(); }
    else if (page === "project") { await loadPublicData(); projectPage(); }
    else if (page === "admin") { await admin(); }
  })();
})();

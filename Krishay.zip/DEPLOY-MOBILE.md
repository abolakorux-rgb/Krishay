# نصب با گوشی

این پروژه به کامپیوتر وابسته نیست، اما چون `src/worker.js` و bindingهای Cloudflare دارد، بهتر است از روش GitHub → Cloudflare استفاده شود.

## مرحله 1: GitHub

یک repository جدید بسازید و فایل‌های این پروژه را با همان ساختار پوشه‌ها داخل آن قرار دهید.

ساختار باید دقیقاً شبیه این باشد:

```text
src/worker.js
public/index.html
public/admin/index.html
public/project/index.html
public/assets/app.js
public/assets/style.css
wrangler.toml
```

## مرحله 2: آماده کردن KV

در Cloudflare وارد Workers & Pages شوید و یک KV namespace بسازید.
ID آن را از Cloudflare بردارید و در `wrangler.toml` جایگزین کنید:

```toml
[[kv_namespaces]]
binding = "CMS_KV"
id = "YOUR_REAL_KV_ID"
```

## مرحله 3: Import از GitHub

در Cloudflare بروید به:

Workers & Pages → Create application → Import an existing Git repository

Repository را انتخاب کنید و Deploy را بزنید.

Cloudflare با migration موجود، Durable Object نوع SQLite را هم برای `AuthDO` ایجاد می‌کند.

## مرحله 4: ورود

بعد از Deploy:

```text
/admin/
```

ورود اولیه:

```text
Email: admin@example.com
Password: admin123
```

بعد از ورود، از بخش تنظیمات ایمیل و رمز مدیر را تغییر دهید.
